from flask import Flask, render_template, request, jsonify
from sklearn.tree import DecisionTreeClassifier
import numpy as np

app = Flask(__name__)

# Dummy training data
X = np.array([
    [80, 70, 90, 20],
    [60, 20, 30, 80],
    [90, 80, 95, 10],
    [70, 60, 85, 30],
])
y = ["overload", "normal", "critical", "warning"]

model = DecisionTreeClassifier()
model.fit(X, y)

def rule_based(data):
    faults = []
    if data["temp"] > 85 and data["vibration"] > 70:
        faults.append("machine_wear")
    if data["current"] > 90 and data["speed"] < 30:
        faults.append("motor_overload")
    if data["network"] > 70:
        faults.append("communication_failure")
    if "motor_overload" in faults and "machine_wear" in faults:
        faults.append("critical_fault")
    return faults

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    data = request.json
    features = [[data["temp"], data["vibration"], data["current"], data["speed"]]]
    ai_result = model.predict(features)[0]
    rules = rule_based(data)
    return jsonify({
        "ai_prediction": ai_result,
        "rule_faults": rules
    })

if __name__ == "__main__":
    app.run(debug=True)
